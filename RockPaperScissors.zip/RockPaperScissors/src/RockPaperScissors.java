import java.util.Scanner;

public class RockPaperScissors {
    public static int lookup(String val){
    String Rock = "";
    String Paper = "";
    String Scissors = "";

    }
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.println("Choose (rock,paper,scissors)");
        String playerChoice = scanner.nextLine();
        int rock = 0;
        int paper = 1;
        int scissors = 2;
        if (playerChoice = 0)  {
        }
            /*
        while (true) {
            String isPlayer1 = "Rock" + "Paper" + "Scissors"; 
            String isPlayer2 = "Rock" + "Paper" + "Scissors";
            while (!isPlayer1.equals("rock") || !isPlayer1.equals("paper") || !isPlayer1.equals("scissors")) {
                System.out.print("Player1 make your move (rock, paper, scissors): ");
                isPlayer1 = scanner.nextLine();
            }
            
           
            while (!isPlayer2.equals("rock") && !isPlayer2.equals("paper") && !isPlayer2.equals("scissors")) {
                System.out.print("Player2 make your move (rock, paper, scissors): ");
                isPlayer2 = scanner.nextLine();
            }
            */
            String winnerMessage = "";
            if (isPlayer1.equals(isPlayer2)) {
                winnerMessage = "The outcome is a tie";
            } else if ((isPlayer1.equals("rock") && isPlayer2.equals("scissors")) ||
                       (isPlayer1.equals("paper") && isPlayer2.equals("rock")) ||
                       (isPlayer1.equals("scissors") && isPlayer2.equals("paper"))) {
                winnerMessage = "Player1 is the winner";
            } else {
                winnerMessage = "Player2 is the winner";
            }
            
            System.out.println(winnerMessage);
            
            String playAgain = "";
            while (!playAgain.equals("y") && !playAgain.equals("n")) {
                System.out.print("Do you want to play again? (y/n): ");
                playAgain = scanner.nextLine();
            }
            
            if (playAgain.equals("n")) {
                break;
            }
        }

    private static void Set(String string) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
        
        scanner.close();
    }
}